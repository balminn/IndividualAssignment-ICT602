package com.example.individualassignment;

public class NumberLimitException extends Throwable {
}
